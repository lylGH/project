﻿ // 万酒抢购倒计时
    function toDub(n){
        return n<10? "0"+n :""+n;
    };
    show_time=function(){
        $(".rushTimeBox li").each(function () {
            var spanTime = $(this).find(".pdate");
            var timeHtml=spanTime.html();
            var time_start = new Date().getTime();
            var time_end =  new Date(timeHtml).getTime();
            var time_distance = time_end - time_start;
            var int_day=0;
            var int_hour=0;
            var int_minute=0;
            var int_second=0;

            if(time_distance>=0){
                int_day = Math.floor(time_distance/86400000);
                time_distance -= int_day * 86400000;
                int_hour = Math.floor(time_distance/3600000)
                time_distance -= int_hour * 3600000;
                int_minute = Math.floor(time_distance/60000)
                time_distance -= int_minute * 60000;
                int_second = Math.floor(time_distance/1000)
                 $(this).find(".endPic").hide();
                $(this).find(".fastSale").addClass("redBg");
            }else{
                $(this).find(".endPic").show();
                $(this).find(".fastSale").addClass("grayBg");
            }

         $(this).find(".dayShow").html(toDub(int_day));
            $(this).find(".hourShow").html(toDub(int_hour));
            $(this).find(".minuteShow").html(toDub(int_minute));
            $(this).find(".secondShow").html(toDub(int_second));
        })
    },
	loop=setInterval(show_time,1000);










