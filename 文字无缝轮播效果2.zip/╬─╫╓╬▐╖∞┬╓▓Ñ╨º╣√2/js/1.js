$(document).ready(function(){
    // 友情链接定时切换效果
    autoPlay=function(){
        $("#news").find("ul:first").animate({
            marginTop:"-1rem"
        },800,function(){
            $(this).css({marginTop:"0px"}).find("li:first").appendTo(this);
        });
    }
    run = setInterval(autoPlay, 2000);
});