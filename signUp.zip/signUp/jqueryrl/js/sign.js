$(function () {
    //页面加载初始化年月
    var mydate = new Date();
    $(".f-year").html(mydate.getFullYear());
    $(".f-month").html(mydate.getMonth() + 1);
    showDate(mydate.getFullYear(), mydate.getMonth() + 1);
    //日历上一月
    $(".f-btn-jian ").click(function () {
        var mm = parseInt($(".f-month").html());
        var yy = parseInt($(".f-year").html());
        if (mm == 1) { //返回12月
            $(".f-year").html(yy - 1);
            $(".f-month").html(12);
            showDate(yy - 1, 12);
        } else { //上一月
            $(".f-month").html(mm - 1);
            showDate(yy, mm - 1);
        }
    })
    //日历下一月
    $(".f-btn-jia").click(function () {
        var mm = parseInt($(".f-month").html());
        var yy = parseInt($(".f-year").html());
        if (mm == 12) { //返回12月
            $(".f-year").html(yy + 1);
            $(".f-month").html(1);
            showDate(yy + 1, 1);
        } else { //上一月
            $(".f-month").html(mm + 1);
            showDate(yy, mm + 1);
        }
    })
    //返回本月
    $(".f-btn-fhby").click(function () {
        $(".f-year").html(mydate.getFullYear());
        $(".f-month").html(mydate.getMonth() + 1);
        showDate(mydate.getFullYear(), mydate.getMonth() + 1);
    });
    //点击签到效果打上酒的标志
    $(".signGiveGift").click(function () {
        var curMonth = mydate.getMonth() + 1,//获取的当前月
            today = mydate.getDate(),
            thisMonth = $(".f-month").html(),//日历取得月份
            lastNum = $(".f-lastMonth").length;
        if (mydate.getFullYear()) {
            if (curMonth == thisMonth) {
                if ($(".f-yuan").hasClass("active")) {
                    $(".shadeMess,.haveSigned,.closeBtn-2").show();
                } else {
                    $(".f-rili-table .f-td").eq(today + lastNum - 1).addClass("f-today").children(".f-yuan").addClass("active");
                    $(".shadeMess,.signSus,.closeBtn-2").show();
                }

            }
        }

    });
    //关闭按钮
    $(".goOn,.closeBtn-2").click(function(){
        $(".shadeMess,.signSus,.closeBtn-2").fadeOut();
    })
    $(".closeBtn-2").click(function(){
        $(".shadeMess,.haveSigned,.closeBtn-2").fadeOut();
    })
    $(".tomAgain").click(function(){
        $(".shadeMess,.haveSigned,.closeBtn-2").fadeOut();
    })

    //读取年月写入日历  重点算法!!!!!!!!!!!  
    var todayDate = showDate(mydate.getFullYear(), mydate.getMonth() + 1);
    console.log(todayDate);

    function showDate(yyyy, mm) {
        var dd = new Date(parseInt(yyyy), parseInt(mm), 0); //Wed Mar 31 00:00:00 UTC+0800 2010  
        var daysCount = dd.getDate(); //本月天数
        var CurMon = dd.getMonth() + 1; //获取当前月  
        var mystr = ""; //写入代码
        var icon = ""; //图标代码
        var today = new Date().getDate(); //今天几号  21
        var monthstart = new Date(parseInt(yyyy) + "/" + parseInt(mm) + "/1").getDay() //本月1日周几  
        var lastMonth; //上一月天数
        var nextMounth //下一月天数
        if (parseInt(mm) == 1) {
            lastMonth = new Date(parseInt(yyyy) - 1, parseInt(12), 0).getDate();
        } else {
            lastMonth = new Date(parseInt(yyyy), parseInt(mm) - 1, 0).getDate();
        }
        if (parseInt(mm) == 12) {
            nextMounth = new Date(parseInt(yyyy) + 1, parseInt(1), 0).getDate();
        } else {
            nextMounth = new Date(parseInt(yyyy), parseInt(mm) + 1, 0).getDate();
        }
        //计算上月空格数
        for (j = monthstart; j > 0; j--) {
            mystr += "<div class='f-td f-null f-lastMonth' style='color:#ccc;'>" + (lastMonth - j + 1) +
                "</div>";
        }

        //本月单元格
        for (i = 0; i < daysCount; i++) {
            //这里为一个单元格，添加内容在此
            mystr += "<div class='f-td'>"
             +"<span class='f-day'>" + (i + 1) + "</span>" 
              +"<div class='f-yuan'></div>"
              // +"<div class='f-table-msg cashShow active'>回款中<span class='major'>1</span>笔。回款本息;<span class='major'>1，000，000</span>元</div>" //这里加判断
                +"<div class='getThings cashShow active pos1'>"
                +"<div class='signGift'>"+'签到送'+"<i>"+'1.66现金'+"</i>"+"</div>"
                +"</div>"
              
                +"</div>";
        }


        //计算下月空格数
        for (k = 0; k < 35 - (daysCount + monthstart); k++) { //表格保持等高6行35个单元格
            mystr += "<div class='f-td f-null f-nextMounth' style='color:#ccc;'>" + (k + 1) + "</div>";
        }

        //写入日历
        $(".f-rili-table .f-tbody").html(mystr);
       
        // 日历背景变化
        if (CurMon == "5") {
            $(".account-box").addClass("bg5");
        } else if (CurMon == "6") {
            $(".account-box").addClass("bg6");
        } else if (CurMon == "7") {
            $(".account-box").addClass("bg7");
        } else if (CurMon == "8") {
            $(".account-box").addClass("bg8");
        } else if (CurMon == "9") {
            $(".account-box").addClass("bg9");
        } else if (CurMon == "10") {
            $(".account-box").addClass("bg10");
        } else if (CurMon == "11") {
            $(".account-box").addClass("bg11");
        } else if (CurMon == "11") {
            $(".account-box").addClass("bg12");
        } else {
            $(".account-box").addClass("bg5");
        }


        //绑定选择方法
        // $(".f-rili-table .f-number").off("click");
        // $(".f-rili-table .f-number").on("click",function(){
        //     $(".f-rili-table .f-number").removeClass("f-on");
        //     $(this).addClass("f-on");
        // });

        //鼠标hover出现送的积分、优惠券、现金
        $(".getThings").off("mouseover");
        $(".getThings").on("mouseover",function(){
            $(this).find(".signGift").show();
        });
        $(".signGift").off("mouseover");
        $(".signGift").on("mouseover",function(){
            $(this).show();
        });
        $(".getThings").off("mouseleave");
        $(".getThings").on("mouseleave",function(){
            $(this).find(".signGift").hide();
        });
         $(".signGift").off("mouseleave");
        $(".signGift").on("mouseleave",function(){
            $(this).hide();
        });

    }
})

//关闭宝箱弹出层
$(".closeBtn").click(function () {
    $(".shadeMess,.shadeCont").hide();
})
//签到效果
// function week(){
//    var objDate= new Date();
//    var week = objDate.getDay();
//    switch(week)
//    {
//        case 0:
//            week="周日";
//            break;
//        case 1:
//            week="周一";
//            break;
//        case 2:
//            week="周二";
//            break;
//        case 3:
//            week="周三";
//            break;
//        case 4:
//            week="周四";
//            break;
//        case 5:
//            week="周五";
//            break;
//        case 6:
//            week="周六";
//            break;
//    }
//    $("#sing_for_number").html("签到");
// }
// $(function(){
//    week();
//    var current = new Date();
//    $(".singer_r_img").click(function(){
//        var s = this;
//        showLoading("正在签到...");
//        $.ajax({
//            url : "${pageContext.request.contextPath}/sign/doSign",
//            type : "POST",
//            dataType : "json",
//            success : function(data) {
//                loadingComplete();
//                var rst = data.result;
//                if(rst == 1) {
//                    showError("今天您已经签到，无须再次签到！",function(){
//                        var signList = data.signList;
//                        $(s).addClass("current");
//                        var str = calUtil.drawCal(current.getFullYear(),current.getMonth() + 1,signList);
//                        $(str).layerModel({title:"签到日历"});
//                    });
//                } else {
//                    showSuccess("签到成功！",function(){
//                        var signList = data.signList;
//                        $(s).addClass("current");
//                        var str = calUtil.drawCal(current.getFullYear(),current.getMonth() + 1,signList);
//                        $(str).layerModel({title:"签到日历"});
//                    });
//                }
//            }
//        });
//    });
// });
